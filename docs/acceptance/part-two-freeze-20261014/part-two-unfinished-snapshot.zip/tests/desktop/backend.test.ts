import { describe, expect, it } from 'vitest';
import { acceptHandshake } from '../../apps/desktop/src/shared/validation';
import { BackendSupervisor, childEnvironment } from '../../apps/desktop/src/main/backend';
import { spawn } from 'node:child_process';
import { mkdtemp,readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, join } from 'node:path';
describe('startup identity fence', () => {
  const ready = { kind:'backend.ready', port:12345, pid:123, instance_id:'expected', protocol_version:'1.0' };
  it('does not accept old occupied port or wrong process identity', () => {
    expect(acceptHandshake({...ready,instance_id:'old-process'},'expected',123)).toBe(false);
    expect(acceptHandshake({...ready,pid:456},'expected',123)).toBe(false);
  });
  it('does not accept unready, invalid port or a different protocol', () => {
    expect(acceptHandshake({...ready,kind:'backend.starting'},'expected',123)).toBe(false);
    expect(acceptHandshake({...ready,port:0},'expected',123)).toBe(false);
    expect(acceptHandshake({...ready,protocol_version:'2.0'},'expected',123)).toBe(false);
  });
});
describe('managed process lifecycle', () => {
  async function supervisor(mode:string) {
    const root=resolve('.');const dataRoot=await mkdtemp(join(tmpdir(),'desktop-unit-'));
    return new BackendSupervisor({root,dataRoot,providerMode:'fake',timeoutMs:300,spawnProcess:((_file:any,_args:any,options:any)=>spawn(process.execPath,[resolve('tests/desktop/support/backend-child.cjs')],{...options,env:{...options.env,TEST_BEHAVIOR:mode}})) as typeof spawn});
  }
  for(const [mode,message] of [['health-timeout','无法连接'],['early-exit','就绪前退出'],['old-port','启动超时']])it(`does not claim readiness for ${mode}`,async()=>{
    const backend=await supervisor(mode);await expect(backend.start()).rejects.toThrow(message);expect(backend.status.state).toBe('offline');
  });
  it('authenticates a healthy owned process and checkpoints shutdown',async()=>{const backend=await supervisor('normal');expect((await backend.start()).state).toBe('ready');expect((await backend.start()).state).toBe('ready');await backend.stop();expect(backend.status.state).toBe('offline');});
  it('a late exit from the previous child cannot disconnect its replacement',async()=>{const backend=await supervisor('normal');await backend.start();const old=(backend as any).child;await backend.stop();await backend.start();try{old.emit('exit',0,null);expect(backend.status.state).toBe('ready');expect(await backend.request('/v1/health')).toHaveProperty('protocol_version','1.0');}finally{await backend.stop();}});
  it('a failed tree cleanup is recorded and blocks a duplicate launch',async()=>{const backend=await supervisor('normal');await backend.start();const options=(backend as any).options;options.spawnTreeKiller=()=>spawn(process.execPath,['-e','process.exit(1)'],{windowsHide:true,stdio:'ignore'});options.terminationTimeoutMs=100;try{await expect(backend.stop()).rejects.toThrow('退出尚未确认');expect(JSON.parse(await readFile(join(options.dataRoot,'desktop-recovery.json'),'utf8')).cleanup_confirmed).toBe(false);await expect(backend.start()).rejects.toThrow('无法重复启动');}finally{options.spawnTreeKiller=undefined;options.terminationTimeoutMs=1500;await backend.stop();}});
  it('does not forward provider or renderer secrets to Python',()=>{process.env.DESKTOP_SECRET_CANARY='secret';process.env.ANTHROPIC_API_KEY='secret';const env=childEnvironment('local-token','instance');expect(env.DESKTOP_SECRET_CANARY).toBeUndefined();expect(env.ANTHROPIC_API_KEY).toBeUndefined();expect(env.WORKBENCH_API_TOKEN).toBe('local-token');delete process.env.DESKTOP_SECRET_CANARY;delete process.env.ANTHROPIC_API_KEY;});
});
