# 协作工作台

阶段二冻结更新：未完成的 D021–D040 已冻结并暂停推进，逐卡遗留、源码与证据快照见[冻结说明](docs/acceptance/part-two-freeze-20261014/FREEZE.md)。

Windows 优先的本地桌面 AI 协作工作台，目标与验收合同见 [DESIGN.md](DESIGN.md) 和 [执行总纲](docs/superpowers/plans/2026-10-13-execution/00-execution-guide.md)。

部分一保持[冻结记录](docs/acceptance/part-one-freeze-20261014/FREEZE.md)。阶段二已增加 Electron/React 桌面、中文输入法与会话材料、语言路由和全文翻译门槛、A 完整原件捕获、双语文件发布、用量/存储/诊断页面，以及可复算的综合用例。逐项实现、测试结果与剩余验收见[阶段二报告](docs/acceptance/part-two-progress.md)。

从仓库根按 [开发手册](docs/runbooks/development.md) 重建环境。D002 的实际命令、退出码、运行版本及源码快照复验记录位于 [工程验收报告](docs/acceptance/D002/implementation-report.md)。默认测试排除真实外部模型，不产生模型调用费用。

桌面从仓库根运行 `npm run build:desktop` 后执行 `npm run desktop`。当前生产模型注册表为空，界面会显示连接不可用；实际 Claude/ZCode 与 GPT 当前生命周期资格仍待补齐。`npm run desktop:demo` 使用明确标记的模拟模型响应，执行实际本地调度、存储和公开消息路径，可用于操作检查，不能计作真实模型验收。

桌面与目录迁移步骤见[桌面运行手册](docs/runbooks/desktop-operations.md)，后端恢复见[后端运行手册](docs/runbooks/backend-operations.md)。默认测试排除真实外部模型；本次没有新增真实模型调用或质量/token 节省声明。
