"""Authenticated loopback API."""
