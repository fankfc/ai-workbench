import secrets
import asyncio
import inspect
from contextlib import closing, asynccontextmanager, suppress
from fastapi import FastAPI,Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from app.config import AppSettings
from app.contracts.providers import ContractModel,NonEmptyString
from app.storage.database import Database
from app.storage.migrations import migrate
from app.storage.blobs import BlobStore
from . import conversations,turns,tasks

class ApiError(ContractModel):
    detail: NonEmptyString

def create_app(settings:AppSettings, *, backend_factory=None)->FastAPI:
    if not isinstance(settings,AppSettings):
        raise TypeError('AppSettings required')
    errors={code:{'model':ApiError} for code in (400,401,403,404,409,422,500)}
    if backend_factory is not None and not callable(backend_factory):
        raise TypeError('Private backend factory required')
    @asynccontextmanager
    async def lifespan(app):
        if backend_factory is None:
            yield
            return
        from app.runtime.supervisor import TaskSupervisor
        bindings=backend_factory(app)
        if inspect.isawaitable(bindings):
            bindings=await bindings
        supervisor=TaskSupervisor(app.state.database.path,bindings,provider_mode=settings.provider_mode)
        supervisor.register_profiles()
        app.state.provider_registry=supervisor.provider_registry
        app.state.supervisor=supervisor
        runner=asyncio.create_task(supervisor.run())
        app.state.supervisor_task=runner
        try:
            yield
        finally:
            await supervisor.shutdown()
            runner.cancel()
            with suppress(asyncio.CancelledError):
                await runner
            app.state.provider_registry={}
    app=FastAPI(title='Local workbench API',version='1.0',docs_url=None,redoc_url=None,responses=errors,lifespan=lifespan)
    app.state.settings=settings
    app.state.provider_registry={}
    app.state.database=Database(settings.data_root/'workbench.sqlite3')
    app.state.blobs=BlobStore(settings.data_root/'blobs')
    with closing(app.state.database.connect()) as connection:
        migrate(connection)
        if settings.provider_mode=='fake':
            for family in ('gpt','glm'):
                connection.execute("INSERT OR IGNORE INTO provider_profiles(id,adapter,model_id,family,connection_id,identity_status,identity_source,connection_version) VALUES (?,?,?,?,?,'unknown',NULL,'test-only')",(f'fake-{family}','fake',f'fixture-{family}',family,f'fake-{family}'))
    app.state.recovery_results=[]
    if settings.startup_recovery:
        from app.runtime.recovery import Recovery
        app.state.recovery_results=Recovery(app.state.database.path).recover(lambda row:{'status':'unknown'})
    @app.middleware('http')
    async def authenticate(request:Request,call_next):
        expected='Bearer '+settings.api_token
        if not secrets.compare_digest(request.headers.get('Authorization','').encode('utf-8'),expected.encode('utf-8')):
            return JSONResponse({'detail':'本地认证失败。'},status_code=401)
        host=request.url.hostname
        allowed={'localhost','127.0.0.1','::1'} | ({'testserver'} if settings.provider_mode=='fake' else set())
        if host not in allowed or request.headers.get('Origin') is not None:
            return JSONResponse({'detail':'请求来源不受支持。'},status_code=403)
        return await call_next(request)
    @app.exception_handler(RequestValidationError)
    async def invalid_request(request,error):
        return JSONResponse({'detail':'请求字段不符合接口要求。'},status_code=422)
    app.include_router(conversations.router)
    app.include_router(turns.router)
    app.include_router(tasks.router)
    return app
