"""Private workflow/publication assembly. HTTP and model data cannot issue it."""
from contextlib import closing
import asyncio

from app.storage.database import Database
from app.contracts.tasks import contract_digest
from .planning import PreparedPlan
from .publication import NativePublisher, PublicationBlocked
from .state_machine import StateMachine, checkpoint_for, require_current_attempt


class NativeTaskExecutor:
    def __init__(self, workflow):
        self.workflow = workflow
        self.database_path = workflow.database_path

    async def execute(self, plan):
        return await self.workflow.run_prepared(plan)

    async def publish(self, plan, result):
        if not isinstance(plan, PreparedPlan) or result.state != 'OUTPUT_PREPARING':
            raise PublicationBlocked('NATIVE_EXECUTION_NOT_APPROVED')
        contract = plan.contract
        with closing(Database(self.database_path).connect()) as connection:
            row = require_current_attempt(connection, contract.task_id, contract.attempt_id, contract.contract_version)
            checkpoint = checkpoint_for(row)
            handoff = checkpoint.get('planning_handoff', {})
            workflow = checkpoint.get('workflow', {})
            if (handoff.get('planning_step_id') != plan.planning_step_id
                    or handoff.get('previous_owner') != plan.owner_token
                    or handoff.get('contract_sha256') != contract_digest(contract)
                    or workflow.get('current_revision_id') != result.current_revision_id
                    or workflow.get('review_check_id') != result.review_check_id
                    or row['state'] not in {'OUTPUT_PREPARING', 'READY', 'PUBLISHED'}):
                raise PublicationBlocked('NATIVE_RESULT_BINDING_REQUIRED')
        workspace = self.workflow.workspaces.create(contract.task_id, contract.attempt_id)
        publisher = NativePublisher(self.database_path, workspace.area('evidence'))
        if row['state'] == 'OUTPUT_PREPARING':
            publisher.stage(contract.task_id, contract.attempt_id, contract.contract_version,
                result.current_revision_id, result.review_check_id)
            StateMachine(self.database_path).transition(contract.task_id, contract.attempt_id,
                'OUTPUT_PREPARING', 'READY', contract.contract_version)
        return publisher.publish(contract.task_id, contract.attempt_id, contract.contract_version)

    async def cancel(self, task_id, attempt_id):
        # Both roles may be waiting; all cleanup results must be inspected.
        values = await asyncio.gather(self.workflow.adapter.cancel(task_id, attempt_id),
            self.workflow.reviewer.cancel(task_id, attempt_id), return_exceptions=True)
        if any(isinstance(value, BaseException) for value in values):
            raise PublicationBlocked('NATIVE_LOCAL_CLEANUP_UNCONFIRMED')
