"""Persistent runtime building blocks."""
