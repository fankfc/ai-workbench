"""Versioned local workbench contracts."""
