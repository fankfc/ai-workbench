# 协作工作台

Windows 优先的本地桌面 AI 协作工作台，目标与验收合同见 [DESIGN.md](DESIGN.md) 和 [执行总纲](docs/superpowers/plans/2026-10-13-execution/00-execution-guide.md)。

部分一已新增持久化后端：认证会话 API、状态/outbox、Windows 进程管理、恢复、任务合同、返修、预算、版本失效、验证器与公开发布门槛。四类固定场景通过测试装置连接这些实际模块；真实 Claude/ZCode 接入仍被登录和模型配置阻塞。逐项状态见[实施报告](docs/acceptance/part-one-progress.md)。桌面界面、完整翻译和双语文档按后续任务实施。

从仓库根按 [开发手册](docs/runbooks/development.md) 重建环境。D002 的实际命令、退出码、运行版本及源码快照复验记录位于 [工程验收报告](docs/acceptance/D002/implementation-report.md)。默认测试排除真实外部模型，不产生模型调用费用。

后端的启动、固定场景、真实接入条件与故障恢复步骤见[运行手册](docs/runbooks/backend-operations.md)。当前生产模型注册表为空，完整产品可用性及质量/token 优化资格尚未验收。
