# 桌面端到端测试

D002 仅建立 Playwright 命令与测试配置。此目录还没有桌面产品测试，首次真实 GUI 测试随 D021 之后的实施建立。

`npm run test:e2e` 实际调用 `playwright test`；没有测试时保持非零退出，不使用 `--pass-with-no-tests` 将缺失测试标为通过。默认排除 `*-real.spec.ts`、`*.real.spec.ts` 和 `real_provider` 目录。真实外部模型场景将在对应任务中通过独立、明确启用的配置运行。
