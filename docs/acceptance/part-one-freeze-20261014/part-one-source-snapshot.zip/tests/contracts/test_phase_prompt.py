import hashlib
import json
from pathlib import Path

import pytest

from app.contracts.tasks import contract_digest, validate_contract
from app.providers.phase_bridge import PhaseBinding, PhaseBridgeError, phase_prompt_text
from support.contracts import make_contract


def binding(phase='execution'):
    contract = validate_contract(make_contract('task', 'attempt', 'route'))
    package = {'sources': [{'content': 'source text', 'trust': 'untrusted_material'}]}
    original = json.dumps(dict(phase=phase, contract=contract.model_dump(mode='json'), evidence_package=package))
    return PhaseBinding('actual-local-request', phase, contract, package, Path('evidence'),
        hashlib.sha256(original.encode()).hexdigest()), original


def test_text_only_model_receives_service_computed_exact_envelope_binding():
    context, original = binding()
    value = json.loads(phase_prompt_text(context, original))
    assert value['fixed_envelope_fields'] == dict(schema_version='1.0', phase='execution',
        request_id='actual-local-request', task_id='task', attempt_id='attempt', contract_version='1.0',
        contract_sha256=contract_digest(context.contract))
    assert value['work'] == json.loads(original)


def test_source_changed_before_prompt_preparation_is_rejected():
    context, original = binding()
    with pytest.raises(PhaseBridgeError):
        phase_prompt_text(context, original + ' ')


def test_review_prompt_carries_original_source_and_mechanical_evidence_without_granting_pass():
    context, original = binding('review')
    value = json.loads(phase_prompt_text(context, original))
    assert value['fixed_envelope_fields']['phase'] == 'review'
    assert 'independently' in value['instruction']
    assert value['work']['evidence_package']['sources'][0]['trust'] == 'untrusted_material'
